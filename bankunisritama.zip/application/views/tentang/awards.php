<!-- Main Body Content Start -->
<main id="body-content">

    <!-- What Makes Us Special Start -->
    <section class="bg-sky-blue wide-tb-ibnu">
        <div class="container">
            <div class="row">
                <h1><?= $page; ?></h1>
            </div>

        </div>

    </section>

    <!-- What Makes Us Special Start -->
    <section class="bg-sky-blue wide-tb-80">
        <div class="container pos-rel">
            <div class="row justify-content-md-center">
                <div class="col-md-6 wow fadeInUp" data-wow-duration="0" data-wow-delay="0s">
                    <p class="h5 text-center">InfoBanks</p>
                </div>
            </div>
        </div>
    </section>
    <!-- What Makes Us Special End -->
</main>