<!-- Main Body Content Start -->
<main id="body-content">

    <!-- What Makes Us Special Start -->
    <section class="bg-sky-blue wide-tb-ibnu">
        <div class="container">
            <div class="row">
                <h1><?= $page; ?></h1>
            </div>
            <div class="row justify-content-md-center wide-tb-80">
                <div class="col-md-6 wow fadeInLeft" data-wow-duration="0" data-wow-delay="0s">
                    <p class="h5 text-center"><em>"PT. BPR Unisritama telah berdiri sejak Senin tanggal 01 April 1991. PT. BPR Unisritama hadir menjadi mitra ekonomi kerakyatan kita bersama"</em></p>
                </div>
            </div>
        </div>
    </section>

</main>